get_taxi_info((Id, Position, Time, Log, Customers_on_board, Back_home), Id, Position, Time, Log, Customers_on_board, Back_home).
get_customer_info((Id, Position, Online_time, Offline_time, Pickup_time, Pickup_taxi), Id, Position, Online_time, Offline_time, Pickup_time, Pickup_taxi).
