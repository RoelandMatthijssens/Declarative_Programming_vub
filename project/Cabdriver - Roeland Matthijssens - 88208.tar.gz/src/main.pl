%:-[test_nodes, test_edges, test_customers, test_taxis].
:-[nodes, edges, customers, taxis].
:-[printing].
:-[shortest_path, dijkstra, cached_dijkstra].
:-[best_customer, drop_off, update_taxi].
:-[help_functions, getters].
:-[main_loop, logging].
:-[test, statistics].
