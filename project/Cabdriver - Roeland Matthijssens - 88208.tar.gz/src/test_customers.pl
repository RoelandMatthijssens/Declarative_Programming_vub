% CUSTOMERS
customer(0, 1141, 1313, 0, 89).
customer(1, 954, 990, 81, 50).
customer(2, 877, 946, 67, 75).
customer(3, 386, 975, 68, 51).
customer(4, 1169, 1220, 64, 74).
customer(5, 525, 1330, 37, 4).
customer(6, 799, 1312, 0, 31).
customer(7, 1362, 1384, 74, 3).
customer(8, 860, 1407, 19, 13).
customer(9, 496, 1421, 24, 76).
customer(10, 769, 1027, 68, 25).
customer(11, 1151, 1366, 17, 51).
