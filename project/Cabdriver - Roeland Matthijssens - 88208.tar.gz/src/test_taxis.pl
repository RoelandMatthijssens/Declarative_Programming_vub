% TAXIS
taxi(0).
taxi(1).
taxi(2).
taxi(3).
taxi(4).
taxi(5).
taxi(6).
taxi(7).
taxi(8).
taxi(9).
taxi(10).
